package com.example.menumakananminuman;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultCaller;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    EditText inputnamapesan;
    Button makanbtn, minumbtn;
    TextView jumlahpesananoutput;
    ActivityResultLauncher<Intent> launcher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult hasil) {
                    if (hasil.getResultCode() == RESULT_OK){
                        String replytext = hasil.getData().getStringExtra(pesanan.lezat2);
                        jumlahpesananoutput.setText(replytext);
                    }
                }
            });

    public static final String lezat = "selesai";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        inputnamapesan = findViewById(R.id.input_namapesanan);
        makanbtn = findViewById(R.id.btn_makanan);
        minumbtn = findViewById(R.id.btn_minuman);
        jumlahpesananoutput = findViewById(R.id.output_jumlah);

        makanbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(v.getContext(), pesanan.class);
                String tv1 = makanbtn.getText().toString();
                String tv2 = inputnamapesan.getText().toString();
                String[] tv = {tv1, tv2};
                intent.putExtra(lezat, tv);
                launcher.launch(intent);
            }
        });

        minumbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(v.getContext(), pesanan.class);
                String tv1 = minumbtn.getText().toString();
                String tv2 = inputnamapesan.getText().toString();
                String[] tv = {tv1, tv2};
                intent.putExtra(lezat, tv);
                launcher.launch(intent);
            }
        });

    }
}
