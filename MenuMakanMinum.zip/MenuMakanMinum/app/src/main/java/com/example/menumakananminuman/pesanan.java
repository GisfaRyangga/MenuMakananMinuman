package com.example.menumakananminuman;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class pesanan extends AppCompatActivity {
    TextView pilihanKategori, outputMenu;
    EditText inputJumlah;
    Button okBtn;

    public static final String lezat2 = "selesai2";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pesanan);
        pilihanKategori = findViewById(R.id.pilihan_kategori);
        outputMenu = findViewById(R.id.output_menu);
        inputJumlah = findViewById(R.id.input_jumlah);
        okBtn = findViewById(R.id.ok_btn);

        Intent intent = getIntent();
        String[] hasil = intent.getStringArrayExtra(MainActivity.lezat);

        pilihanKategori.setText(hasil[0]);
        outputMenu.setText(hasil[1]);

        okBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                String rplyMsg = inputJumlah.getText().toString();
                intent.putExtra(lezat2, rplyMsg);

                setResult(RESULT_OK, intent);
                finish();
            }
        });
    }
}